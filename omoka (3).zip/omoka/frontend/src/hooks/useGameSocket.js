import { useEffect, useRef, useState, useCallback } from "react";
import { io } from "socket.io-client";

const SERVER_URL = import.meta.env.VITE_SERVER_URL || "http://localhost:4000";

const emptySlot = () => ({ bet: null, cashoutResult: null });

// `getToken` is an async function returning a fresh Firebase ID token (or
// null if signed out). It's called fresh on every connect/reconnect
// attempt via socket.io's function-form `auth` option, so a token that
// expired while the tab was idle gets renewed automatically on reconnect.
export function useGameSocket(getToken, userId) {
  const socketRef = useRef(null);
  const [phase, setPhase] = useState("connecting"); // waiting | flying | crashed
  const [multiplier, setMultiplier] = useState(1.0);
  const [seedHash, setSeedHash] = useState(null);
  const [lastCrash, setLastCrash] = useState(null); // { crashPoint, serverSeed, ... }
  const [history, setHistory] = useState([]);
  const [config, setConfig] = useState({ minBetCents: 1000, maxBetCents: 5000000, maxBetsPerRound: 2 });
  // slots keyed by slot number: { [slot]: { bet: {betId, amount, autoCashoutAt} | null, cashoutResult } }
  const [slots, setSlots] = useState({ 1: emptySlot(), 2: emptySlot() });

  useEffect(() => {
    const socket = io(SERVER_URL, {
      auth: async (cb) => {
        try {
          const token = await getToken?.();
          cb(token ? { token } : {});
        } catch {
          cb({});
        }
      },
    });
    socketRef.current = socket;

    socket.on("round:state", (data) => {
      setPhase(data.state);
      setSeedHash(data.seedHash);
      if (data.config) setConfig((c) => ({ ...c, ...data.config }));
    });

    socket.on("round:waiting", (data) => {
      setPhase("waiting");
      setSeedHash(data.seedHash);
      setMultiplier(1.0);
      setSlots({ 1: emptySlot(), 2: emptySlot() });
      if (data.config) setConfig((c) => ({ ...c, ...data.config }));
    });

    socket.on("round:flying", () => {
      setPhase("flying");
    });

    socket.on("round:tick", (data) => {
      setMultiplier(data.multiplier / 100);
    });

    // Broadcast to everyone — only react if it's this client's own user
    // (needed for auto-cashouts, which fire server-side with no direct ack).
    socket.on("bet:cashed_out", (data) => {
      if (!userId || data.userId !== userId) return;
      setSlots((s) => ({
        ...s,
        [data.slot]: { bet: null, cashoutResult: data },
      }));
    });

    socket.on("round:crashed", (data) => {
      setPhase("crashed");
      setLastCrash(data);
      setHistory((h) => [{ crashPoint: data.crashPoint, roundId: data.roundId }, ...h].slice(0, 20));
    });

    return () => socket.disconnect();
  }, [userId]);

  const placeBet = useCallback((amountCents, slot = 1, autoCashoutAt = null) => {
    return new Promise((resolve) => {
      socketRef.current.emit("bet:place", { amountCents, slot, autoCashoutAt }, (res) => {
        if (res?.ok) {
          setSlots((s) => ({
            ...s,
            [slot]: { bet: { betId: res.betId, amount: amountCents, autoCashoutAt }, cashoutResult: null },
          }));
        }
        resolve(res);
      });
    });
  }, []);

  const cashOut = useCallback((slot = 1) => {
    return new Promise((resolve) => {
      socketRef.current.emit("bet:cashout", { slot }, (res) => {
        if (res?.ok) {
          setSlots((s) => ({ ...s, [slot]: { bet: null, cashoutResult: res } }));
        }
        resolve(res);
      });
    });
  }, []);

  return {
    phase,
    multiplier,
    seedHash,
    lastCrash,
    history,
    config,
    slots,
    placeBet,
    cashOut,
  };
}
