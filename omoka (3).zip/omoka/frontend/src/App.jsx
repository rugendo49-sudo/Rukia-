import { useState } from "react";
import AuthForm from "./components/AuthForm.jsx";
import Landing from "./components/Landing.jsx";
import MultiplierDisplay from "./components/MultiplierDisplay.jsx";
import BetPanel from "./components/BetPanel.jsx";
import History from "./components/History.jsx";
import Leaderboard from "./components/Leaderboard.jsx";
import MyStatsChart from "./components/MyStatsChart.jsx";
import AdminDashboard from "./components/AdminDashboard.jsx";
import { useGameSocket } from "./hooks/useGameSocket.js";
import { useAuth } from "./hooks/useAuth.js";

export default function App() {
  const { appUser, loading, authError, signUp, signIn, logout, getFreshIdToken, refreshBalance } = useAuth();
  const [tab, setTab] = useState("play"); // play | leaderboard | stats | admin

  const userId = appUser?.id ?? null;
  const { phase, multiplier, seedHash, lastCrash, history, config, slots, placeBet, cashOut } =
    useGameSocket(getFreshIdToken, userId);

  // Balance can change from bets/cashouts (handled locally by the socket
  // hook's acks) but a phase change is a good moment to double check it's
  // still in sync with the server.
  const balance = appUser?.balance ?? 0;

  if (loading) {
    return <div className="app-shell centered muted">Loading…</div>;
  }

  if (!appUser) {
    return (
      <Landing>
        <AuthForm signUp={signUp} signIn={signIn} authError={authError} />
      </Landing>
    );
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <h1>Omoka</h1>
        <div className="topbar-right">
          <span className="username-label">{appUser.username}</span>
          <button className="link-btn" onClick={logout}>
            Log out
          </button>
        </div>
      </header>

      <nav className="tab-nav">
        <button className={tab === "play" ? "active" : ""} onClick={() => setTab("play")}>
          Play
        </button>
        <button className={tab === "leaderboard" ? "active" : ""} onClick={() => setTab("leaderboard")}>
          Leaderboard
        </button>
        <button className={tab === "stats" ? "active" : ""} onClick={() => setTab("stats")}>
          My Stats
        </button>
        {appUser.isAdmin && (
          <button className={tab === "admin" ? "active" : ""} onClick={() => setTab("admin")}>
            Admin
          </button>
        )}
      </nav>

      {tab === "play" && (
        <>
          <History history={history} />
          <MultiplierDisplay phase={phase} multiplier={multiplier} lastCrash={lastCrash} seedHash={seedHash} />
          <BetPanel
            phase={phase}
            balance={balance}
            config={config}
            slots={slots}
            placeBet={async (...args) => {
              const res = await placeBet(...args);
              if (res?.ok) refreshBalance();
              return res;
            }}
            cashOut={async (...args) => {
              const res = await cashOut(...args);
              if (res?.ok) refreshBalance();
              return res;
            }}
          />
        </>
      )}

      {tab === "leaderboard" && <Leaderboard />}
      {tab === "stats" && <MyStatsChart getToken={getFreshIdToken} />}
      {tab === "admin" && appUser.isAdmin && <AdminDashboard getToken={getFreshIdToken} />}
    </div>
  );
}
