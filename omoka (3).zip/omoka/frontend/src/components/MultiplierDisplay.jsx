// Sunburst ray background, generated once — same visual idea as the classic
// crash-game "explosion" backdrop, built as plain SVG lines (no copied art).
function SunburstRays() {
  const rayCount = 16;
  const rays = Array.from({ length: rayCount }, (_, i) => {
    const angle = (360 / rayCount) * i;
    return <line key={i} x1="200" y1="200" x2="200" y2="-40" transform={`rotate(${angle} 200 200)`} />;
  });
  return (
    <svg className="sunburst-rays" viewBox="0 0 400 400" preserveAspectRatio="none">
      {rays}
    </svg>
  );
}

export default function MultiplierDisplay({ phase, multiplier, lastCrash, seedHash }) {
  return (
    <div className={`multiplier-stage multiplier-stage--${phase}`}>
      <SunburstRays />

      <div className="multiplier-stage-content">
        {phase === "waiting" && <div className="waiting-label">Place your bet — next round boarding…</div>}

        {phase === "flying" && <div className="multiplier-value multiplier-value--flying">{multiplier.toFixed(2)}x</div>}

        {phase === "crashed" && lastCrash && (
          <>
            <div className="flew-away-label">FLEW AWAY!</div>
            <div className="multiplier-value multiplier-value--crashed">
              {(lastCrash.crashPoint / 100).toFixed(2)}x
            </div>
          </>
        )}
      </div>

      <div className="fairness-line">
        {phase === "waiting" && seedHash && (
          <span title={seedHash}>Round hash committed: {seedHash.slice(0, 16)}…</span>
        )}
        {phase === "crashed" && lastCrash && (
          <span title={lastCrash.serverSeed}>
            Seed revealed: {lastCrash.serverSeed.slice(0, 16)}… (verify anytime)
          </span>
        )}
      </div>
    </div>
  );
}
