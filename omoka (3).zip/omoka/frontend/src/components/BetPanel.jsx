import { useState } from "react";

function SlotPanel({ slotNum, phase, balance, slotState, config, placeBet, cashOut }) {
  const [amount, setAmount] = useState("10.00");
  const [autoTarget, setAutoTarget] = useState("");
  const [msg, setMsg] = useState(null);

  const minAmt = (config.minBetCents / 100).toFixed(2);
  const maxAmt = (config.maxBetCents / 100).toFixed(2);
  const { bet, cashoutResult } = slotState;

  async function handleBet() {
    setMsg(null);
    const cents = Math.round(parseFloat(amount) * 100);
    if (!cents || cents < config.minBetCents) return setMsg(`Min bet is KES ${minAmt}`);
    if (cents > config.maxBetCents) return setMsg(`Max bet is KES ${maxAmt}`);

    let autoCashoutAt = null;
    if (autoTarget.trim() !== "") {
      const parsed = Math.round(parseFloat(autoTarget) * 100);
      if (!parsed || parsed < 101) return setMsg("Auto-cashout target must be at least 1.01x");
      autoCashoutAt = parsed;
    }

    const res = await placeBet(cents, slotNum, autoCashoutAt);
    if (res?.error) setMsg(res.error);
  }

  async function handleCashOut() {
    setMsg(null);
    const res = await cashOut(slotNum);
    if (res?.error) setMsg(res.error);
  }

  return (
    <div className="bet-slot">
      <div className="bet-slot-header">Bet {slotNum}</div>

      <div className="bet-controls">
        <input
          type="number"
          min={minAmt}
          max={maxAmt}
          step="1"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          disabled={phase !== "waiting" || !!bet}
        />
        {!bet && (
          <button className="btn-bet" onClick={handleBet} disabled={phase !== "waiting"}>
            Bet
          </button>
        )}
        {bet && phase === "flying" && (
          <button className="btn-cashout" onClick={handleCashOut}>
            Cash Out
          </button>
        )}
        {bet && phase === "waiting" && <span className="bet-pending">Placed</span>}
      </div>

      <div className="auto-cashout-row">
        <label>Auto cash out at</label>
        <input
          type="number"
          min="1.01"
          step="0.01"
          placeholder="off"
          value={autoTarget}
          onChange={(e) => setAutoTarget(e.target.value)}
          disabled={phase !== "waiting" || !!bet}
        />
        <span>x</span>
      </div>
      {bet?.autoCashoutAt && (
        <div className="auto-cashout-active">Auto-cashout armed: {(bet.autoCashoutAt / 100).toFixed(2)}x</div>
      )}

      {cashoutResult && (
        <div className="cashout-banner">
          {cashoutResult.auto ? "Auto-" : ""}Cashed out at {(cashoutResult.multiplier / 100).toFixed(2)}x — won
          KES {(cashoutResult.payout / 100).toFixed(2)}
        </div>
      )}
      {msg && <div className="bet-msg">{msg}</div>}
    </div>
  );
}

export default function BetPanel({ phase, balance, config, slots, placeBet, cashOut }) {
  return (
    <div className="bet-panel">
      <div className="balance-line">Balance: KES {(balance / 100).toFixed(2)}</div>
      <div className="bet-slots-grid">
        {Array.from({ length: config.maxBetsPerRound }, (_, i) => i + 1).map((slotNum) => (
          <SlotPanel
            key={slotNum}
            slotNum={slotNum}
            phase={phase}
            balance={balance}
            slotState={slots[slotNum] || { bet: null, cashoutResult: null }}
            config={config}
            placeBet={placeBet}
            cashOut={cashOut}
          />
        ))}
      </div>
    </div>
  );
}
