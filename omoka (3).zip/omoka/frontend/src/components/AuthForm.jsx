import { useState } from "react";

export default function AuthForm({ signUp, signIn, authError }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "login") {
        await signIn(email, password);
      } else {
        await signUp(email, password);
      }
    } catch {
      // authError is already set by useAuth; nothing else to do here.
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-card">
      <h2>{mode === "login" ? "Log in" : "Create your account"}</h2>
      <p className="auth-sub">
        {mode === "login" ? "Welcome back — place your bet." : "Takes a few seconds, no real money involved."}
      </p>
      <form onSubmit={submit}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          placeholder="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          minLength={6}
          required
        />
        {authError && <div className="auth-error">{authError}</div>}
        <button type="submit" disabled={loading}>
          {loading ? "..." : mode === "login" ? "Log in" : "Sign up"}
        </button>
      </form>
      <button className="link-btn" onClick={() => setMode(mode === "login" ? "register" : "login")}>
        {mode === "login" ? "Need an account? Sign up" : "Already have an account? Log in"}
      </button>
    </div>
  );
}
