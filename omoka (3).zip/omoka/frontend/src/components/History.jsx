export default function History({ history }) {
  return (
    <div className="history-bar">
      {history.map((h) => {
        const val = h.crashPoint / 100;
        const cls = val < 2 ? "low" : val < 5 ? "mid" : "high";
        return (
          <span key={h.roundId} className={`history-pill ${cls}`}>
            {val.toFixed(2)}x
          </span>
        );
      })}
    </div>
  );
}
