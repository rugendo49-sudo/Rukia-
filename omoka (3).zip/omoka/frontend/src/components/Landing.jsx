import LiveCurvePreview from "./LiveCurvePreview.jsx";

const STEPS = [
  {
    n: "01",
    title: "Bet before takeoff",
    body: "Place your stake during the short boarding window, before the plane leaves the ground.",
  },
  {
    n: "02",
    title: "Watch the multiplier climb",
    body: "Once it's airborne, your potential payout grows with every second it stays in the air.",
  },
  {
    n: "03",
    title: "Cash out before it crashes",
    body: "Tap cash out any time. Wait too long and the plane crashes — your stake goes with it.",
  },
];

export default function Landing({ children }) {
  function scrollToAuth() {
    document.getElementById("auth-section")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <div className="landing">
      <section className="hero">
        <div className="hero-copy">
          <div className="hero-eyebrow">OMOKA · CRASH GAME</div>
          <h1 className="hero-headline">
            Bet before
            <br />
            it flies away.
          </h1>
          <p className="hero-sub">
            A multiplier climbs from the moment the round takes off. Cash out whenever you like —
            just don't wait too long, because it can crash at any second.
          </p>
          <div className="hero-ctas">
            <button className="hero-btn hero-btn--primary" onClick={scrollToAuth}>
              Create free account
            </button>
            <button className="hero-btn hero-btn--ghost" onClick={scrollToAuth}>
              Log in
            </button>
          </div>
          <div className="hero-fineprint">Every round is provably fair — verify any result yourself.</div>
        </div>

        <div className="hero-visual">
          <LiveCurvePreview />
          <div className="hero-visual-caption">A real round, live on Omoka right now</div>
        </div>
      </section>

      <section className="steps-section">
        <h2 className="section-heading">How a round works</h2>
        <div className="steps-grid">
          {STEPS.map((s) => (
            <div className="step-card" key={s.n}>
              <div className="step-number">{s.n}</div>
              <div className="step-title">{s.title}</div>
              <div className="step-body">{s.body}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="fairness-section">
        <h2 className="section-heading">Provably fair, not just promised</h2>
        <p className="fairness-body">
          Before each round starts, Omoka publishes a cryptographic hash of that round's outcome —
          locked in before anyone bets. Once the round ends, the underlying value is revealed so you
          can recompute the hash yourself and confirm the result was set in advance, not adjusted
          after you placed your bet.
        </p>
      </section>

      <section id="auth-section" className="auth-section">
        {children}
      </section>
    </div>
  );
}
