import { db, GAME_CONFIG } from "../db/index.js";
import { generateServerSeed, hashSeed, computeCrashPoint } from "./provablyFair.js";

const WAITING_MS = 6000; // betting window
const TICK_MS = 100; // multiplier update interval
const GROWTH = 0.00012; // controls curve steepness

const { MIN_BET_CENTS, MAX_BET_CENTS, MAX_BETS_PER_ROUND, MAX_AUTO_CASHOUT } = GAME_CONFIG;

// multiplier(t) = e^(GROWTH * t_ms), in hundredths, rounded down
function multiplierAtElapsed(elapsedMs) {
  const m = Math.exp(GROWTH * elapsedMs);
  return Math.max(100, Math.floor(m * 100));
}

function elapsedForMultiplier(targetHundredths) {
  const m = targetHundredths / 100;
  return Math.log(m) / GROWTH;
}

function slotKey(userId, slot) {
  return `${userId}:${slot}`;
}

export class RoundManager {
  constructor(io) {
    this.io = io;
    this.roundId = null;
    this.state = "idle";
    this.crashPoint = null;
    this.serverSeed = null;
    this.seedHash = null;
    this.clientSeed = "omoka-public-seed"; // could be per-round mixed with player-submitted seeds
    this.flyStart = null;
    // key: `${userId}:${slot}` -> { userId, slot, amount, betId, cashedOut, autoCashoutAt }
    this.activeBets = new Map();
    this.tickTimer = null;
  }

  start() {
    this.newRound();
  }

  newRound() {
    this.serverSeed = generateServerSeed();
    this.seedHash = hashSeed(this.serverSeed);

    const info = db
      .prepare(
        `INSERT INTO rounds (server_seed, seed_hash, client_seed, status) VALUES (?, ?, ?, 'waiting')`
      )
      .run(this.serverSeed, this.seedHash, this.clientSeed);
    this.roundId = Number(info.lastInsertRowid);

    this.crashPoint = computeCrashPoint(this.serverSeed, this.roundId, this.clientSeed);
    this.state = "waiting";
    this.activeBets.clear();

    this.io.emit("round:waiting", {
      roundId: this.roundId,
      seedHash: this.seedHash, // commitment only — seed itself stays secret till crash
      waitMs: WAITING_MS,
      config: { minBetCents: MIN_BET_CENTS, maxBetCents: MAX_BET_CENTS, maxBetsPerRound: MAX_BETS_PER_ROUND },
    });

    setTimeout(() => this.startFlying(), WAITING_MS);
  }

  startFlying() {
    this.state = "flying";
    this.flyStart = Date.now();
    db.prepare(`UPDATE rounds SET status = 'flying' WHERE id = ?`).run(this.roundId);
    this.io.emit("round:flying", { roundId: this.roundId, startedAt: this.flyStart });

    const crashElapsed = elapsedForMultiplier(this.crashPoint) * 1000;

    this.tickTimer = setInterval(() => {
      const elapsed = Date.now() - this.flyStart;
      const current = multiplierAtElapsed(elapsed);
      this.io.emit("round:tick", { roundId: this.roundId, multiplier: current });

      this.processAutoCashouts(current);

      if (elapsed >= crashElapsed) {
        clearInterval(this.tickTimer);
        this.crash();
      }
    }, TICK_MS);
  }

  // Checks every still-active bet against its auto-cashout target and
  // settles any that have reached it, before the tick's multiplier passes
  // the crash point. Runs once per tick, same cadence as the broadcast.
  processAutoCashouts(currentMultiplier) {
    if (currentMultiplier >= this.crashPoint) return; // crash() will settle these as losses
    for (const bet of this.activeBets.values()) {
      if (bet.cashedOut) continue;
      if (bet.autoCashoutAt && currentMultiplier >= bet.autoCashoutAt) {
        const result = this.settleCashOut(bet, bet.autoCashoutAt);
        this.io.emit("bet:cashed_out", {
          userId: bet.userId,
          slot: bet.slot,
          auto: true,
          ...result,
        });
      }
    }
  }

  crash() {
    this.state = "crashed";

    // Settle any bets that never cashed out
    for (const bet of this.activeBets.values()) {
      if (!bet.cashedOut) {
        db.prepare(`UPDATE bets SET status = 'lost', payout = 0 WHERE id = ?`).run(bet.betId);
      }
    }

    db.prepare(
      `UPDATE rounds SET status = 'crashed', crash_point = ? WHERE id = ?`
    ).run(this.crashPoint, this.roundId);

    this.io.emit("round:crashed", {
      roundId: this.roundId,
      crashPoint: this.crashPoint,
      serverSeed: this.serverSeed, // reveal for verification
      seedHash: this.seedHash,
      clientSeed: this.clientSeed,
    });

    setTimeout(() => this.newRound(), 3000);
  }

  placeBet(userId, amountCents, slot = 1, autoCashoutAt = null) {
    if (this.state !== "waiting") throw new Error("Betting is closed for this round");
    if (!Number.isInteger(slot) || slot < 1 || slot > MAX_BETS_PER_ROUND) {
      throw new Error(`Invalid bet slot (must be 1-${MAX_BETS_PER_ROUND})`);
    }
    if (this.activeBets.has(slotKey(userId, slot))) {
      throw new Error("You already have a bet in that slot this round");
    }
    if (!Number.isInteger(amountCents) || amountCents < MIN_BET_CENTS) {
      throw new Error(`Minimum bet is KES ${(MIN_BET_CENTS / 100).toFixed(2)}`);
    }
    if (amountCents > MAX_BET_CENTS) {
      throw new Error(`Maximum bet is KES ${(MAX_BET_CENTS / 100).toFixed(2)}`);
    }
    if (autoCashoutAt !== null) {
      if (!Number.isInteger(autoCashoutAt) || autoCashoutAt < 101 || autoCashoutAt > MAX_AUTO_CASHOUT) {
        throw new Error("Auto-cashout target must be between 1.01x and " + (MAX_AUTO_CASHOUT / 100) + "x");
      }
    }

    const user = db.prepare(`SELECT balance FROM users WHERE id = ?`).get(userId);
    if (!user || user.balance < amountCents) throw new Error("Insufficient balance");

    db.prepare(`UPDATE users SET balance = balance - ? WHERE id = ?`).run(amountCents, userId);
    const info = db
      .prepare(
        `INSERT INTO bets (round_id, user_id, slot, amount, auto_cashout_multiplier, status) VALUES (?, ?, ?, ?, ?, 'active')`
      )
      .run(this.roundId, userId, slot, amountCents, autoCashoutAt);

    const bet = {
      userId,
      slot,
      amount: amountCents,
      betId: Number(info.lastInsertRowid),
      cashedOut: false,
      autoCashoutAt,
    };
    this.activeBets.set(slotKey(userId, slot), bet);

    return { betId: bet.betId, roundId: this.roundId, slot, autoCashoutAt };
  }

  // Shared by manual and auto cashouts so both paths pay out identically.
  settleCashOut(bet, multiplier) {
    const payout = Math.floor((bet.amount * multiplier) / 100);
    bet.cashedOut = true;

    db.prepare(
      `UPDATE bets SET status = 'cashed_out', cashout_multiplier = ?, payout = ? WHERE id = ?`
    ).run(multiplier, payout, bet.betId);
    db.prepare(`UPDATE users SET balance = balance + ? WHERE id = ?`).run(payout, bet.userId);

    const balance = db.prepare(`SELECT balance FROM users WHERE id = ?`).get(bet.userId).balance;
    return { multiplier, payout, balance, slot: bet.slot };
  }

  cashOut(userId, slot = 1) {
    if (this.state !== "flying") throw new Error("Round is not active");
    const bet = this.activeBets.get(slotKey(userId, slot));
    if (!bet || bet.cashedOut) throw new Error("No active bet to cash out in that slot");

    const elapsed = Date.now() - this.flyStart;
    const multiplier = multiplierAtElapsed(elapsed);
    if (multiplier >= this.crashPoint) throw new Error("Too late — round already crashed");

    return this.settleCashOut(bet, multiplier);
  }
}
