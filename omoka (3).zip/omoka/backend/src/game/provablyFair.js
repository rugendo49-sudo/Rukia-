import crypto from "crypto";

const HOUSE_EDGE = 0.99; // 1% house edge
const MAX_HEX_INT = Math.pow(2, 52);

// Safety ceiling on the crash multiplier. Mathematically the formula below
// can already produce far larger values (we've seen 300,000x+ in
// simulation), but a hard cap keeps round durations bounded and gives
// players/marketing a concrete "biggest possible win" number to point to.
// Reaching anywhere near this is expected to be extremely rare by design —
// capping it doesn't change the odds of getting here, it just stops the
// (near-impossible) case of an even more extreme value.
const MAX_CRASH_MULTIPLIER = 20000_00; // 20,000.00x, stored in hundredths

/**
 * Generates a fresh random server seed (hex string).
 * Kept secret until the round finishes.
 */
export function generateServerSeed() {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Publishes a commitment to the seed BEFORE the round starts.
 * Players see this hash; after the round the raw seed is revealed
 * so they can recompute the hash themselves and confirm it matches,
 * proving the crash point wasn't chosen after bets were placed.
 */
export function hashSeed(serverSeed) {
  return crypto.createHash("sha256").update(serverSeed).digest("hex");
}

/**
 * Combines the server seed with a round-specific nonce (roundId) and
 * optionally a client seed (players can supply their own to add entropy).
 * Returns the crash multiplier in hundredths (e.g. 235 => 2.35x).
 */
export function computeCrashPoint(serverSeed, roundId, clientSeed = "omoka") {
  const combined = `${serverSeed}:${roundId}:${clientSeed}`;
  const hash = crypto.createHash("sha256").update(combined).digest("hex");

  // Use the first 13 hex chars (52 bits) as the source of randomness,
  // normalized to a uniform value in [0, 1).
  const h = parseInt(hash.slice(0, 13), 16);
  const X = h / MAX_HEX_INT;

  // ~1% chance of an instant crash at 1.00x, matching the house edge.
  if (X < 1 - HOUSE_EDGE) return 100;

  const crash = Math.floor((HOUSE_EDGE / (1 - X)) * 100);
  return Math.min(MAX_CRASH_MULTIPLIER, Math.max(100, crash)); // clamp to [1.00x, 20,000.00x]
}

/**
 * Verifies a round after the fact. Anyone (frontend, third party) can
 * run this with the revealed serverSeed + roundId to confirm the
 * published crash point was legitimate.
 */
export function verifyRound(serverSeed, roundId, clientSeed, claimedCrashPoint, claimedHash) {
  const recomputedHash = hashSeed(serverSeed);
  const recomputedCrash = computeCrashPoint(serverSeed, roundId, clientSeed);
  return {
    hashMatches: recomputedHash === claimedHash,
    crashMatches: recomputedCrash === claimedCrashPoint,
    recomputedHash,
    recomputedCrash,
  };
}
