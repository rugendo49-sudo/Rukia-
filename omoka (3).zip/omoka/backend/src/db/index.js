import { DatabaseSync } from "node:sqlite";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const db = new DatabaseSync(path.join(__dirname, "omoka.sqlite"));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  firebase_uid TEXT UNIQUE NOT NULL,
  email TEXT,
  display_name TEXT,
  balance INTEGER NOT NULL DEFAULT 100000, -- stored in cents (1000.00 signup bonus)
  is_admin INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_seed TEXT NOT NULL,
  seed_hash TEXT NOT NULL,
  client_seed TEXT NOT NULL,
  crash_point INTEGER, -- hundredths, e.g. 235 = 2.35x
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting | flying | crashed
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  round_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  slot INTEGER NOT NULL DEFAULT 1, -- 1 or 2 — players may run two concurrent bets per round
  amount INTEGER NOT NULL, -- cents
  auto_cashout_multiplier INTEGER, -- hundredths; null = manual cashout only
  cashout_multiplier INTEGER, -- hundredths, null if not cashed out
  payout INTEGER, -- cents
  status TEXT NOT NULL DEFAULT 'active', -- active | cashed_out | lost
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (round_id) REFERENCES rounds(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
`);

// Config: kept here so both the round manager and the REST config
// endpoint read the same source of truth.
export const GAME_CONFIG = {
  MIN_BET_CENTS: 1000, // KES 10.00
  MAX_BET_CENTS: 5_000_000, // KES 50,000.00
  MAX_BETS_PER_ROUND: 2, // number of concurrent bet slots per player
  MAX_AUTO_CASHOUT: 100_000, // 1000.00x ceiling, sanity bound
};

export default db;
