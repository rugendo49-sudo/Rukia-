import { Router } from "express";
import { requireAuth } from "./middleware.js";
import { db } from "../db/index.js";
import { displayNameFor } from "../auth/userSync.js";

const router = Router();

// Called once after the client signs in/up with Firebase. requireAuth
// already verified the token and created/looked-up the local user row;
// this just returns that row's app-specific state (balance, admin flag)
// in the shape the frontend expects.
router.post("/session", requireAuth, (req, res) => {
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(req.userId);
  res.json({
    user: {
      id: user.id,
      username: displayNameFor(user),
      email: user.email,
      balance: user.balance,
      isAdmin: !!user.is_admin,
    },
  });
});

export default router;
