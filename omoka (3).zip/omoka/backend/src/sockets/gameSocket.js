import { verifySocketAuth } from "../routes/middleware.js";
import { db, GAME_CONFIG } from "../db/index.js";

export function attachGameSocket(io, roundManager) {
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(); // allow anonymous viewers (read-only)
    const identity = await verifySocketAuth(token);
    if (identity) {
      socket.userId = identity.userId;
      socket.isAdmin = identity.isAdmin;
    }
    next();
  });

  io.on("connection", (socket) => {
    // Send current state snapshot to the newly connected client
    socket.emit("round:state", {
      roundId: roundManager.roundId,
      state: roundManager.state,
      seedHash: roundManager.seedHash,
      config: {
        minBetCents: GAME_CONFIG.MIN_BET_CENTS,
        maxBetCents: GAME_CONFIG.MAX_BET_CENTS,
        maxBetsPerRound: GAME_CONFIG.MAX_BETS_PER_ROUND,
      },
    });

    // payload: { amountCents, slot (1..maxBetsPerRound, default 1), autoCashoutAt (hundredths, optional) }
    socket.on("bet:place", (payload, ack) => {
      if (!socket.userId) return ack?.({ error: "Login required" });
      try {
        const slot = payload.slot ?? 1;
        const autoCashoutAt = payload.autoCashoutAt ?? null;
        const result = roundManager.placeBet(socket.userId, payload.amountCents, slot, autoCashoutAt);
        const balance = db.prepare(`SELECT balance FROM users WHERE id = ?`).get(socket.userId).balance;
        ack?.({ ok: true, ...result, balance });
        io.emit("bet:new", { userId: socket.userId, amount: payload.amountCents, slot });
      } catch (err) {
        ack?.({ error: err.message });
      }
    });

    // payload: { slot (default 1) }
    socket.on("bet:cashout", (payload, ack) => {
      if (!socket.userId) return ack?.({ error: "Login required" });
      try {
        const slot = payload?.slot ?? 1;
        const result = roundManager.cashOut(socket.userId, slot);
        ack?.({ ok: true, ...result });
        io.emit("bet:cashed_out", { userId: socket.userId, auto: false, ...result });
      } catch (err) {
        ack?.({ error: err.message });
      }
    });
  });
}
